import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-excursions',
  templateUrl: './excursions.component.html',
  styleUrls: ['./excursions.component.css']
})
export class ExcursionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
