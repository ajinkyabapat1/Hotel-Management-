import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-westerns-weddings',
  templateUrl: './westerns-weddings.component.html',
  styleUrls: ['./westerns-weddings.component.css']
})
export class WesternsWeddingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
