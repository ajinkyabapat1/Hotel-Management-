import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thai-weddings',
  templateUrl: './thai-weddings.component.html',
  styleUrls: ['./thai-weddings.component.css']
})
export class ThaiWeddingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
