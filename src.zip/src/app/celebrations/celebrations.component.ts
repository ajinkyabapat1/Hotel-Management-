import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-celebrations',
  templateUrl: './celebrations.component.html',
  styleUrls: ['./celebrations.component.css']
})
export class CelebrationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
